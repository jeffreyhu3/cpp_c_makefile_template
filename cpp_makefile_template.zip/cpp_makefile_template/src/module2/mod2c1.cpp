#include <iostream>

#include <module2/mod2c1.hpp>

void mod2c1::foo()  { std::cout << "mod2c1\n"; }


