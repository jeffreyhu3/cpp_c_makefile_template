#include <iostream>

#include <module2/mod2c2.hpp>

void mod2c2::foo()  { std::cout << "mod2c2\n"; }




