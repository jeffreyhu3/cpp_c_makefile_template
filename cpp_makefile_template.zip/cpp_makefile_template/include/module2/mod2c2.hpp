#ifndef MOD2C2_HPP
#define MOD2C2_HPP

#include <iostream>

class mod2c2
{
public:

   void foo();
};

#endif

